import "./styles.css";
import Temp from "./components/weather/temp"
export default function App() {
  return (
    <>
   <Temp/>
   </>
  );
};
